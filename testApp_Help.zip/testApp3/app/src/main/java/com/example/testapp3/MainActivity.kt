package com.example.testapp3

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


abstract class MainActivity : AppCompatActivity() {

private Button aYesbutton;



    abstract var aYesButton: Any
    abstract var aNoButton: Any

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        aYesButton = findViewById(R.id.yes)
        aNoButton = findViewById(R.id.No)

        
        aYesButton = this.setOnClickListener (View.this.setOnClickListener()) {

            @Override
             Void onClick (View_View)
        }




        Toast.makeText(MainActivity.this, R.string.Correct_answer, Toast.LENGTH_LONG) .show())
        Toast.makeText(MainActivity.this, R.string.Incorrect_answer, Toast.LENGTH_LONG) .show())


        aNoButton = findViewById(R.id.No)
        aNoButton = this.setOnClickListener (View.this.setOnClickListener())
    }

    private fun setOnClickListener(any: Any): Any {

    }


}


}
